package com.example.navegacaosimplesapp

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import androidx.navigation.NavController

@Composable
fun TelaImagemTexto(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Mostra a imagem
        Image(
            painter = painterResource(id = R.drawable.imagem), // troque "imagem" pelo nome do seu arquivo de imagem
            contentDescription = "Exemplo de imagem",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .height(200.dp)
                .fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Mostra o texto
        Text(
            text = "Essa é a tela com imagem e texto.",
            fontSize = 20.sp
        )

        Spacer(modifier = Modifier.height(32.dp))

        Button(onClick = { navController.navigate("main") }) {
            Text("Voltar à Tela Principal")
        }
    }
}
